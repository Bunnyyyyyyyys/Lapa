package com.example.shopappanimal

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class AdminChatActivity : AppCompatActivity() {

    private val TAG = "AdminChatActivity"
    private val db    by lazy { FirebaseFirestore.getInstance() }

    private lateinit var userId: String
    private lateinit var rv: RecyclerView
    private lateinit var adapter: ChatAdapter
    private lateinit var input: EditText
    private lateinit var btnSend: Button

    // простой «юзернейм» для админа
    private val adminId = "admin"

    private val messages = mutableListOf<ChatMessage>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_chat)

        // 1) Получаем userId (UID клиента) из Intent
        userId = intent.getStringExtra("userId") ?: run {
            finish()
            return
        }

        supportActionBar?.title = "Чат с $userId"

        // 2) Привязываем вьюхи
        rv      = findViewById(R.id.recyclerViewMessages)
        input   = findViewById(R.id.editTextMessage)
        btnSend = findViewById(R.id.buttonSend)

        // 3) Настраиваем RecyclerView
        adapter = ChatAdapter(messages, adminId)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        // 4) Подписка на сообщения
        db.collection("supportChats")
            .document(userId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    Log.w(TAG, "Ошибка при прослушивании", e)
                    return@addSnapshotListener
                }
                messages.clear()
                snap?.toObjects(ChatMessage::class.java)?.let {
                    messages.addAll(it)
                    adapter.notifyDataSetChanged()
                    if (messages.isNotEmpty()) {
                        rv.scrollToPosition(messages.size - 1)
                    }
                }
            }

        // 5) Отправка от имени админа
        btnSend.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val msg = ChatMessage(
                senderId   = adminId,
                senderName = "Служба поддержки",
                message    = text,
                timestamp  = Timestamp.now(),
                senderPhone= "" // тут можно оставить пустым
            )

            db.collection("supportChats")
                .document(userId)
                .collection("messages")
                .add(msg)
                .addOnSuccessListener {
                    input.text.clear()
                }
                .addOnFailureListener { ex ->
                    Log.e(TAG, "Ошибка при отправке сообщения", ex)
                }
        }
    }
}
