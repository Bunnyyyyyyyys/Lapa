package com.example.shopappanimal

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.firebase.firestore.FirebaseFirestore

class register : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val fio: TextView = findViewById(R.id.fio)
        val phonetext: TextView = findViewById(R.id.phonetext)
        val passwordtext: TextView = findViewById(R.id.passwordtext)
        val buttonGo: ConstraintLayout = findViewById(R.id.buttonGo)

        buttonGo.setOnClickListener {
            buttonGo.isEnabled = false

            // Проверка на минимальную длину полей
            if (phonetext.text.length >= 6 && fio.text.length >= 6 && passwordtext.text.length >= 6) {
                // Шифрование пароля и телефона
                val eh = EncryptionHelper("G8BnK9Qfuntk9vl6")
                val db = FirebaseFirestore.getInstance()

                // Разделение ФИО на части: фамилия, имя, отчество
                val textfio = fio.text.split(" ")
                if (textfio.size != 3) {
                    buttonGo.isEnabled = true
                    Toast.makeText(this@register, "Проверьте корректность ФИО!", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                // Создание объекта пользователя
                val user = hashMapOf(
                    "name" to textfio[1],  // Имя
                    "password" to eh.encrypt(passwordtext.text.toString()),  // Зашифрованный пароль
                    "phone" to eh.encrypt(phonetext.text.toString()),  // Зашифрованный телефон
                    "surname" to textfio[0],  // Фамилия
                    "thirdname" to textfio[2],  // Отчество
                    "balance" to 0
                )

                // Добавление пользователя в базу данных
                db.collection("users").add(user).addOnSuccessListener { documentReference ->
                    // Сохранение данных пользователя в SharedPreferences
                    val sharedPreferences = getSharedPreferences("IN", MODE_PRIVATE).edit()
                    sharedPreferences.putString("userId", documentReference.id)
                    sharedPreferences.putString("name", textfio[1])  // Сохраняем имя
                    sharedPreferences.putString("vhod", "1")
                    sharedPreferences.putString("surname", textfio[0])  // Сохраняем фамилию
                    sharedPreferences.putString("thirdname", textfio[2])  // Сохраняем отчество
                    sharedPreferences.putString("ID", documentReference.id)  // Сохраняем ID пользователя
                    sharedPreferences.putString("phone", phonetext.text.toString())  // Сохраняем телефон
                    sharedPreferences.putString("password", passwordtext.text.toString())  // Сохраняем пароль
                    sharedPreferences.apply()

                    // Переход на главный экран после успешной регистрации
                    startActivity(Intent(this@register, alldone::class.java))
                    finish()  // Закрытие текущей активности
                }.addOnFailureListener {
                    buttonGo.isEnabled = true
                    Toast.makeText(this@register, "Ошибка при регистрации!", Toast.LENGTH_LONG).show()
                }
            } else {
                buttonGo.isEnabled = true
                Toast.makeText(this@register, "Проверьте поля!", Toast.LENGTH_LONG).show()
            }
        }
    }
}
