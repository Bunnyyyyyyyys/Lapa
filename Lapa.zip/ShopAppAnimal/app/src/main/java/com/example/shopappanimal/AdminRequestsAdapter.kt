package com.example.shopappanimal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.shopappanimal.PetRequestWithPet
import android.widget.Button

class AdminRequestsAdapter(
    private var requests: List<PetRequestWithPet>,
    private val onStatusChange: (PetRequestWithPet, String) -> Unit,
    private val onDelete: (PetRequestWithPet) -> Unit
) : RecyclerView.Adapter<AdminRequestsAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val type: TextView = itemView.findViewById(R.id.petTypeText)
        val phone: TextView = itemView.findViewById(R.id.buyerPhoneTextView)
        val statusSpinner: Spinner = itemView.findViewById(R.id.statusSpinner)
        val deleteButton: Button = itemView.findViewById(R.id.deleteButton)
        val noteTextView: TextView = itemView.findViewById(R.id.noteTextView)
    }

    private val statuses = listOf("ожидает связи", "уже едет", "дома")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_admin_request, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int = requests.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val request = requests[position]
        val pet = request.pet

        holder.type.text = pet.type
        holder.phone.text = "Покупатель: ${request.buyerPhone}"
        holder.noteTextView.text = "Примечание: ${pet.note?.ifBlank { "нет" } ?: "нет"}"

        // Настраиваем спиннер
        holder.statusSpinner.adapter = ArrayAdapter(
            holder.itemView.context,
            android.R.layout.simple_spinner_dropdown_item,
            statuses
        )
        val currentIndex = statuses.indexOf(request.status).coerceAtLeast(0)
        holder.statusSpinner.setSelection(currentIndex)
        holder.statusSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                pos: Int,
                id: Long
            ) {
                val selected = statuses[pos]
                if (selected != request.status) {
                    onStatusChange(request, selected)
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        // Кнопка удаления — всегда показываем, и зовём callback
        holder.deleteButton.setOnClickListener {
            onDelete(request)
        }
    }

    //Обновить список и перерисовать RecyclerView
    fun updateRequests(newRequests: List<PetRequestWithPet>) {
        this.requests = newRequests
        notifyDataSetChanged()
    }
}

