// UserChatActivity.kt
package com.example.shopappanimal

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

class UserChatActivity : AppCompatActivity() {

    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var userId: String
    private val encryptionHelper = EncryptionHelper("G8BnK9Qfuntk9vl6")

    // UI
    private lateinit var recyclerView: RecyclerView
    private lateinit var editTextMessage: EditText
    private lateinit var buttonSend: Button

    // Data
    private val messages = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_chat)

        // 1) Получаем userId из Intent
        userId = intent.getStringExtra("userId") ?: run {
            Toast.makeText(this, "Нет ID пользователя", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // 2) Берём rawPhone и rawName из SharedPreferences
        val prefs   = getSharedPreferences("IN", MODE_PRIVATE)
        val rawPhone = prefs.getString("phone", "")!!
        val rawName  = prefs.getString("name", "Пользователь")!!

        // 3) Находим UI и настраиваем RecyclerView + adapter
        recyclerView     = findViewById(R.id.recyclerViewMessages)
        editTextMessage  = findViewById(R.id.editTextMessage)
        buttonSend       = findViewById(R.id.buttonSend)

        adapter = ChatAdapter(messages, userId)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter        = adapter

        // 4) Подписка на историю сообщений
        db.collection("supportChats")
            .document(userId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, _ ->
                messages.clear()
                snap?.toObjects(ChatMessage::class.java)?.let { messages.addAll(it) }
                adapter.notifyDataSetChanged()
                recyclerView.scrollToPosition(messages.size - 1)
            }

        // 5) Отправка нового сообщения
        buttonSend.setOnClickListener {
            val text = editTextMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            // Шифруем телефон перед записью
            val encPhone = encryptionHelper.encrypt(rawPhone)
            val msg = ChatMessage(
                senderId    = userId,
                senderName  = rawName,    // ← здесь используем rawName
                message     = text,
                timestamp   = Timestamp.now(),
                senderPhone = encPhone
            )

            val chatRef = db.collection("supportChats").document(userId)
            // Обновляем поле userPhone в корневом документе
            chatRef.set(mapOf("userPhone" to encPhone), SetOptions.merge())
            // Добавляем само сообщение
            chatRef.collection("messages").add(msg)

            editTextMessage.text.clear()
        }
    }
}
