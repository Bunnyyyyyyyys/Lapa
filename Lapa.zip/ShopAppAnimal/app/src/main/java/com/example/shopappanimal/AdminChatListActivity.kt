package com.example.shopappanimal

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import android.widget.TextView
import android.view.View


class AdminChatListActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AdminChatListAdapter
    private lateinit var textNoMessages: TextView

    private val userIds    = mutableListOf<String>()
    private val userNames  = mutableListOf<String>()
    private val userPhones = mutableListOf<String>()

    private val db = FirebaseFirestore.getInstance()
    private val encryptionHelper = EncryptionHelper("G8BnK9Qfuntk9vl6")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_chat_list)

        recyclerView = findViewById(R.id.recyclerViewChatUsers)
        textNoMessages = findViewById(R.id.textNoMessages)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = AdminChatListAdapter(this, userIds, userNames, userPhones)
        recyclerView.adapter = adapter

        loadChats()
    }

    private fun loadChats() {
        db.collection("supportChats")
            .get()
            .addOnSuccessListener { supportDocs ->
                userIds.clear()
                userNames.clear()
                userPhones.clear()

                if (supportDocs.isEmpty) {
                    textNoMessages.visibility = View.VISIBLE
                    recyclerView.visibility = View.GONE
                    return@addOnSuccessListener
                } else {
                    textNoMessages.visibility = View.GONE
                    recyclerView.visibility = View.VISIBLE
                }

                supportDocs.forEach { chatDoc ->
                    val uid = chatDoc.id
                    userIds.add(uid)

                    db.collection("users").document(uid)
                        .get()
                        .addOnSuccessListener { userDoc ->
                            val name = userDoc.getString("name") ?: "Без имени"
                            val encPhone = userDoc.getString("phone") ?: ""
                            val phone = runCatching {
                                encryptionHelper.decrypt(encPhone)
                            }.getOrDefault("—")

                            userNames.add(name)
                            userPhones.add(phone)

                            if (userNames.size == userIds.size &&
                                userPhones.size == userIds.size) {
                                adapter.notifyDataSetChanged()
                            }
                        }
                }
            }
    }
}
