package com.example.shopappanimal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class ChatAdapter(
    private val messages: List<ChatMessage>,
    private val currentUserId: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_LEFT  = 0
        private const val VIEW_RIGHT = 1
    }

    // 1) Тип вью по senderId
    override fun getItemViewType(position: Int): Int {
        return if (messages[position].senderId == currentUserId) VIEW_RIGHT else VIEW_LEFT
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = when (viewType) {
            VIEW_RIGHT -> R.layout.item_message_right
            else       -> R.layout.item_message_left
        }
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return object : RecyclerView.ViewHolder(view) {}
    }

    // 2) В onBind расшифровываем перед показом
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        val tvMessage = holder.itemView.findViewById<TextView>(R.id.messageText)
        val tvSender  = holder.itemView.findViewById<TextView>(R.id.messageSender)

        tvMessage.text = msg.message

        // Показываем имя отправителя (если оно есть)
        if (msg.senderName.isNotBlank()) {
            tvSender.text = msg.senderName
            tvSender.visibility = View.VISIBLE
        } else {
            tvSender.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int = messages.size
}
