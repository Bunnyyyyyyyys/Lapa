package com.example.shopappanimal

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.firebase.firestore.FirebaseFirestore

class Login : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Проверка авторизации при запуске приложения
        checkIfUserIsLoggedIn()

        val phonetext: TextView = findViewById(R.id.phonetext)
        val passwordtext: TextView = findViewById(R.id.passwordtext)
        val reg: TextView = findViewById(R.id.reg)
        val buttonGo: ConstraintLayout = findViewById(R.id.buttonGo)

        // Кнопка для перехода на страницу регистрации
        reg.setOnClickListener {
            startActivity(Intent(this@Login, register::class.java))
        }

        buttonGo.setOnClickListener {
            buttonGo.isEnabled = false

            val enteredPhone = phonetext.text.toString().trim()
            val enteredPassword = passwordtext.text.toString().trim()

            if (enteredPhone.isNotEmpty() && enteredPassword.isNotEmpty()) {
                val db = FirebaseFirestore.getInstance()
                db.collection("users").get().addOnSuccessListener { result ->
                    var found = false
                    Log.d("Firestore", "Получено ${result.size()} документов")

                    for (doc in result) {
                        val eh = EncryptionHelper("G8BnK9Qfuntk9vl6")

                        val encryptedPhone = doc.getString("phone")
                        val encryptedPassword = doc.getString("password")

                        Log.d("Firestore", "Документ ID: ${doc.id}, Encrypted Phone: $encryptedPhone, Encrypted Password: $encryptedPassword")

                        if (encryptedPhone != null && encryptedPassword != null) {
                            val phone = eh.decrypt(encryptedPhone).trim()
                            val password = eh.decrypt(encryptedPassword).trim()

                            Log.d("Firestore", "Документ: ${doc.data}")  // Печать всех данных документа

                            Log.d("Firestore", "Расшифрованный Phone: $phone, Password: $password")

                            // Проверяем введенные данные с теми, что хранятся в БД
                            if (enteredPhone == phone && enteredPassword == password) {
                                found = true
                                Log.d("Firestore", "✅ Пользователь найден! ID: ${doc.id}")

                                // Сохраняем данные пользователя в SharedPreferences для последующего использования
                                val sharedPreferences = getSharedPreferences("IN", MODE_PRIVATE).edit()
                                sharedPreferences.putString("vhod", "1") // Флаг успешной авторизации
                                sharedPreferences.putString("name", doc.getString("name"))
                                sharedPreferences.putString("surname", doc.getString("surname"))
                                sharedPreferences.putString("thirdname", doc.getString("thirdname"))
                                sharedPreferences.putString("ID", doc.id)
                                sharedPreferences.putString("phone", phone)
                                sharedPreferences.putString("password", password)
                                sharedPreferences.apply()

                                // Переход к следующей странице после успешного входа
                                startActivity(Intent(this@Login, alldone::class.java))
                                finish()
                                return@addOnSuccessListener
                            }
                        }
                    }

                    // Если пользователь не найден, выводим ошибку
                    if (!found) {
                        Log.d("Firestore", "❌ Пользователь не найден!")
                        buttonGo.isEnabled = true
                        Toast.makeText(this@Login, "Неверный номер телефона или пароль", Toast.LENGTH_LONG).show()
                    }
                }.addOnFailureListener { exception ->
                    Log.e("Firestore", "🔥 Ошибка с БД!", exception)
                    buttonGo.isEnabled = true
                    Toast.makeText(this@Login, "Ошибка с БД!", Toast.LENGTH_LONG).show()
                }
            } else {
                Log.d("Firestore", "⚠️ Поля не заполнены!")
                buttonGo.isEnabled = true
                Toast.makeText(this@Login, "Проверьте все поля!", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Проверка, если пользователь уже авторизован
    private fun checkIfUserIsLoggedIn() {
        val sharedPreferences = getSharedPreferences("IN", MODE_PRIVATE)
        val loggedIn = sharedPreferences.getString("vhod", null)

        // Если флаг "vhod" равен 1, значит пользователь уже авторизован
        if (loggedIn == "1") {
            // Переход на главную страницу
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    override fun onBackPressed() {
        // Запрещаем возврат на предыдущую страницу
    }
}
