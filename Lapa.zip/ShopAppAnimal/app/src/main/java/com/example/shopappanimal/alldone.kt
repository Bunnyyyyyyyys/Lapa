package com.example.shopappanimal

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.annotation.SuppressLint
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import android.net.Uri

class alldone : AppCompatActivity() {

    private lateinit var tvGreeting: TextView
    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alldone)

        tvGreeting = findViewById(R.id.tvGreeting)
        val buttonGo: ConstraintLayout = findViewById(R.id.buttonGo)
        val buttonGoToHome: ConstraintLayout = findViewById(R.id.buttonGoToHome) // Кнопка для перехода на главный экран

        // Получаем данные из SharedPreferences для проверки авторизации
        val sharedPreferences = getSharedPreferences("IN", MODE_PRIVATE)
        val userName = sharedPreferences.getString("name", "Гость") ?: "Гость"

        // Устанавливаем приветствие с именем
        tvGreeting.text = "Привет, $userName!"

        // Кнопка для перехода в тест
        buttonGo.setOnClickListener {
            startActivity(Intent(this, TestActivity::class.java))
            finish()
        }

        // Кнопка для перехода на главный экран
        buttonGoToHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java)) // Переход на главный экран
            finish()
        }

        findViewById<TextView>(R.id.supportPhoneTextView).setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:+78001234567")
            }
            startActivity(intent)
        }

    }

    @SuppressLint("MissingSuperCall")  // подавляем ворнинг, чтобы не вызывать super.onBackPressed()
    override fun onBackPressed() {
        // блокируем кнопку «Назад» — ничего не делаем
    }
}
