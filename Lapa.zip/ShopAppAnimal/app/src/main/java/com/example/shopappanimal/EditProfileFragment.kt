package com.example.shopappanimal.fragments

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.shopappanimal.R
import com.example.shopappanimal.EncryptionHelper
import com.google.firebase.firestore.FirebaseFirestore

class EditProfileFragment : Fragment() {

    private lateinit var nameEditText: EditText
    private lateinit var phoneEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var changePasswordButton: Button

    private val db by lazy { FirebaseFirestore.getInstance() }
    private val encryptionKey = "G8BnK9Qfuntk9vl6"

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_edit_profile, container, false)

        nameEditText = view.findViewById(R.id.nameEditText)
        phoneEditText = view.findViewById(R.id.phoneEditText)
        saveButton = view.findViewById(R.id.saveButton)
        changePasswordButton = view.findViewById(R.id.changePasswordButton)

        loadUserData()

        saveButton.setOnClickListener { saveUserData() }
        changePasswordButton.setOnClickListener { showChangePasswordDialog() }

        return view
    }

    private fun loadUserData() {
        val prefs = requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)
        nameEditText.setText(prefs.getString("name", ""))
        phoneEditText.setText(prefs.getString("phone", ""))
    }

    private fun saveUserData() {
        val newName = nameEditText.text.toString().trim()
        val newPhone = phoneEditText.text.toString().trim()

        if (newName.isEmpty() || newPhone.isEmpty()) {
            Toast.makeText(requireContext(), "Пожалуйста, заполните все поля", Toast.LENGTH_SHORT).show()
            return
        }

        val prefs = requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)
        val userId = prefs.getString("ID", null) ?: run {
            Toast.makeText(requireContext(), "Ошибка: ID пользователя не найден", Toast.LENGTH_SHORT).show()
            return
        }

        val helper = EncryptionHelper(encryptionKey)
        val encryptedPhone = helper.encrypt(newPhone)

        val updates = mapOf(
            "name" to newName,
            "phone" to encryptedPhone
        )

        db.collection("users").document(userId)
            .update(updates)
            .addOnSuccessListener {
                prefs.edit()
                    .putString("name", newName)
                    .putString("phone", newPhone)
                    .apply()
                Toast.makeText(requireContext(), "Данные обновлены", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Ошибка обновления: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun showChangePasswordDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_change_password, null)
        val oldPwdInput = dialogView.findViewById<EditText>(R.id.oldPasswordInput)
        val newPwdInput = dialogView.findViewById<EditText>(R.id.newPasswordInput)
        val confirmPwdInput = dialogView.findViewById<EditText>(R.id.confirmPasswordInput)

        oldPwdInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        newPwdInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        confirmPwdInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD

        val builder = AlertDialog.Builder(requireContext(), R.style.CustomDialog)
        builder.setTitle("Смена пароля")
            .setView(dialogView)
            .setPositiveButton("Сменить") { _, _ ->
                val oldPwd = oldPwdInput.text.toString()
                val newPwd = newPwdInput.text.toString()
                val confirm = confirmPwdInput.text.toString()
                changePassword(oldPwd, newPwd, confirm)
            }
            .setNegativeButton("Отмена", null)

        val dialog = builder.create()
        dialog.window?.attributes?.windowAnimations = R.style.DialogAnimation
        dialog.show()
    }


    private fun changePassword(oldPwd: String, newPwd: String, confirm: String) {
        if (newPwd != confirm) {
            Toast.makeText(requireContext(), "Новый пароль не совпадает", Toast.LENGTH_SHORT).show()
            return
        }

        val prefs = requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)
        val userId = prefs.getString("ID", null) ?: run {
            Toast.makeText(requireContext(), "Ошибка: ID пользователя не найден", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { doc ->
                val encryptedStored = doc.getString("password")
                if (encryptedStored.isNullOrEmpty()) {
                    Toast.makeText(requireContext(), "Пароль не задан", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                val helper = EncryptionHelper(encryptionKey)
                val storedPwd = helper.decrypt(encryptedStored)

                if (storedPwd != oldPwd) {
                    Toast.makeText(requireContext(), "Старый пароль введён неверно", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                val newEncrypted = helper.encrypt(newPwd)
                db.collection("users").document(userId)
                    .update("password", newEncrypted)
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(), "Пароль успешно изменён", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(requireContext(), "Ошибка при сохранении: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Ошибка при получении данных: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
}
