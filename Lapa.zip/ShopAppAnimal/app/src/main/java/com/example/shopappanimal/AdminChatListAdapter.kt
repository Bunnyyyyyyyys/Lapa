package com.example.shopappanimal

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class AdminChatListAdapter(
    private val context: Context,
    private val userIds: MutableList<String>,
    private val userNames: MutableList<String>,
    private val userPhones: MutableList<String>
) : RecyclerView.Adapter<AdminChatListAdapter.ViewHolder>() {

    private val db = FirebaseFirestore.getInstance()

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.textUserName)
        val tvPhone: TextView = view.findViewById(R.id.textUserPhone)
        val btnClear: Button = view.findViewById(R.id.buttonClearHistory)

        init {
            // Клик по карточке — открываем чат
            view.setOnClickListener {
                val uid = userIds[adapterPosition]
                context.startActivity(
                    Intent(context, AdminChatActivity::class.java)
                        .putExtra("userId", uid)
                )
            }

            // Клик по кнопке очистки
            btnClear.setOnClickListener {
                val uid = userIds[adapterPosition]
                val chatDocRef = db.collection("supportChats").document(uid)

                // Удаляем всю подколлекцию messages
                chatDocRef.collection("messages")
                    .get()
                    .addOnSuccessListener { snap ->
                        val batch = db.batch()
                        snap.documents.forEach { doc ->
                            batch.delete(doc.reference)
                        }

                        // Сначала удалим сообщения
                        batch.commit()
                            .addOnSuccessListener {
                                // Затем удалим сам документ чата
                                chatDocRef.delete()
                                    .addOnSuccessListener {
                                        Toast.makeText(context,
                                            "Чат полностью удалён",
                                            Toast.LENGTH_SHORT).show()

                                        // Можно удалить пользователя из списков адаптера и обновить
                                        userIds.removeAt(adapterPosition)
                                        userNames.removeAt(adapterPosition)
                                        userPhones.removeAt(adapterPosition)
                                        notifyItemRemoved(adapterPosition)
                                    }
                                    .addOnFailureListener { e ->
                                        Toast.makeText(context,
                                            "Ошибка удаления документа: ${e.message}",
                                            Toast.LENGTH_SHORT).show()
                                    }
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(context,
                                    "Ошибка при удалении сообщений: ${e.message}",
                                    Toast.LENGTH_SHORT).show()
                            }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context,
                            "Не удалось получить сообщения: ${e.message}",
                            Toast.LENGTH_SHORT).show()
                    }
            }

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_user, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvName.text = userNames[position]
        holder.tvPhone.text = userPhones[position]
    }

    override fun getItemCount(): Int = userIds.size
}
