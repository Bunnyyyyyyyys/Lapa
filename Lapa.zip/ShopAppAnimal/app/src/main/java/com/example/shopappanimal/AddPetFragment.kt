package com.example.shopappanimal.fragments

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.children
import androidx.fragment.app.Fragment
import com.cloudinary.Cloudinary
import com.cloudinary.utils.ObjectUtils
import com.example.shopappanimal.PetRecommendation
import com.example.shopappanimal.Question
import com.example.shopappanimal.R
import com.example.shopappanimal.databinding.FragmentAddPetBinding
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.concurrent.thread
import android.app.Activity

class AddPetFragment : Fragment() {
    private var _binding: FragmentAddPetBinding? = null
    private val binding get() = _binding!!

    private lateinit var cloudinary: Cloudinary
    private var selectedImageUri: Uri? = null
    private val questionsMap = mutableListOf<Question>()

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            selectedImageUri = result.data!!.data
            binding.imagePreview.setImageURI(selectedImageUri)
        }
    }

    // Читаем ID пользователя из тех же SharedPreferences, что в MainActivity
    private val ownerId: String?
        get() = context
            ?.getSharedPreferences("IN", Context.MODE_PRIVATE)
            ?.getString("ID", null)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddPetBinding.inflate(inflater, container, false)

        // Инициализация Cloudinary
        val config = mapOf(
            "cloud_name" to "dfwednqqy",
            "api_key" to "478855117939718",
            "api_secret" to "Faw_qHD1RmBmDPMO_4IkriMvPCk"
        )
        cloudinary = Cloudinary(config)

        // Настройка Spinner категорий
        val categoryAdapter = ArrayAdapter.createFromResource(
            requireContext(),
            R.array.pet_categories,
            android.R.layout.simple_spinner_item
        ).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        binding.spinnerCategory.adapter = categoryAdapter

        binding.spinnerCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View?, pos: Int, id: Long
            ) {
                val category = parent.getItemAtPosition(pos) as String
                handleCategorySelection(category)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {}
        }

        // Программно выбираем первую категорию и вызываем обработку
        val initialCategory = categoryAdapter.getItem(0)?.toString() ?: "Кошки"
        handleCategorySelection(initialCategory)

        binding.buttonSelectImage.setOnClickListener { pickImage() }
        binding.buttonSavePet.setOnClickListener { savePet() }

        return binding.root
    }

    private fun handleCategorySelection(category: String) {
        showFormFields(category)
        loadSpecificQuestions(category)
        binding.criteriaContainer.removeAllViews()
        showQuestionFields()
    }


    private fun showFormFields(category: String) {
        with(binding) {
            editType.visibility        = View.VISIBLE
            editDescription.visibility = View.VISIBLE
            editDeposit.visibility     = View.VISIBLE
            editLocation.visibility    = View.VISIBLE
            editFullPrice.visibility   = View.VISIBLE
            imagePreview.visibility    = View.VISIBLE
            buttonSelectImage.visibility = View.VISIBLE
            buttonSavePet.visibility     = View.VISIBLE

            editType.hint = if (category == "Рыбы") "Вид рыбы" else "Порода"
        }
    }

    private fun loadSpecificQuestions(category: String) {
        questionsMap.clear()
        val list = when (category) {
            "Собаки" -> listOf(
                Question("Какой уровень активности?", listOf("Высокий", "Средний", "Низкий")),
                Question("Какой размер собаки?", listOf("Маленький", "Средний", "Большой")),
                Question("Аллергенная ли собака?", listOf("Да", "Нет")),
                Question("Нуждается ли собака в дрессировке?", listOf("Да", "Нет")),
                Question("Хорошо ли ладит собака с детьми?", listOf("Да", "Нет")),
                Question("Является ли собака охранной?", listOf("Да", "Нет"))
            )
            "Кошки" -> listOf(
                Question("Какой уровень активности?", listOf("Игривая", "Спокойная")),
                Question("Какой тип шерсти", listOf("Короткая", "Длинная", "Гипоаллергенная")),
                Question("Аллергенная ли кошка?", listOf("Да", "Нет")),
                Question("Нуждается в частом внимании?", listOf("Да", "Нет")),
                Question("Нуждается в заимодействии с человеком?", listOf("Очень важно", "Не обязательно"))
            )
            "Грызуны" -> listOf(
                Question("Какой размер грызуна?", listOf("Маленький", "Средний")),
                Question("Какой тип ухода?", listOf("Минимальный", "Средний")),
                Question("Насколько важно взаимодействие с питомцем?", listOf("Очень важно", "Не обязательно"))
            )
            "Птицы" -> listOf(
                Question("Какой размер птицы?", listOf("Маленькая", "Средняя", "Большая")),
                Question("Какой уровень шума?", listOf("Тихая", "Средний уровень", "Громкая"))
            )
            "Рыбы" -> listOf(
                Question("Какая сложность ухода?", listOf("Простая", "Средняя", "Сложная")),
                Question("Какой размер аквариума нужен?", listOf("Маленький", "Средний", "Большой"))
            )
            else -> emptyList()
        }
        questionsMap.addAll(list)
    }

    private fun showQuestionFields() {
        if (questionsMap.isEmpty()) return
        binding.criteriaContainer.visibility = View.VISIBLE
        questionsMap.forEach { q ->
            val tv = TextView(requireContext()).apply { text = q.questionText }
            val rg = RadioGroup(requireContext())
            q.options.forEach { opt ->
                rg.addView(RadioButton(requireContext()).apply { text = opt })
            }
            binding.criteriaContainer.addView(tv)
            binding.criteriaContainer.addView(rg)
        }
    }

    private fun pickImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImageLauncher.launch(intent)
    }

    private fun savePet() {
        // Проверяем авторизацию через SharedPreferences
        val userId = ownerId
        if (userId.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
            return
        }

        // Собираем поля
        val petId      = UUID.randomUUID().toString()
        val category   = binding.spinnerCategory.selectedItem as String
        val type       = binding.editType.text.toString().trim()
        val description= binding.editDescription.text.toString().trim()
        val deposit    = binding.editDeposit.text.toString().trim()
        val location   = binding.editLocation.text.toString().trim()
        val fullPrice  = binding.editFullPrice.text.toString().trim()
        val criteria   = binding.criteriaContainer.children
            .filterIsInstance<RadioGroup>()
            .mapNotNull { rg -> rg.findViewById<RadioButton>(rg.checkedRadioButtonId)?.text?.toString() }
            .toList()

        val basePet = PetRecommendation(
            petId      = petId,
            type       = type,
            category   = category,
            description= description,
            imageUrl   = "",
            imageRes   = 0,
            criteria   = criteria,
            deposit    = deposit,
            location   = location,
            fullPrice  = fullPrice,
            status     = "Ожидает",
            ownerId    = userId
        )

        // Загрузка фото в Cloudinary
        selectedImageUri?.let { uri ->
            val file = File(requireContext().cacheDir, "upload_$petId.jpg")
            requireContext().contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            thread {
                try {
                    val params = ObjectUtils.asMap(
                        "upload_preset", "shopapp_unsigned",
                        "folder", "pets"
                    )
                    val result = cloudinary.uploader().upload(file, params)
                    val uploadedUrl = result["secure_url"] as? String ?: ""
                    Log.d("CloudinaryUpload", "Uploaded URL: $uploadedUrl")
                    val petWithImage = basePet.copy(imageUrl = uploadedUrl)
                    requireActivity().runOnUiThread { saveToFirestore(petWithImage) }
                } catch (e: Exception) {
                    e.printStackTrace()
                    requireActivity().runOnUiThread { saveToFirestore(basePet) }
                }
            }
        } ?: saveToFirestore(basePet)
    }

    private fun saveToFirestore(pet: PetRecommendation) {
        Firebase.firestore.collection("pets").document(pet.petId)
            .set(pet)
            .addOnSuccessListener {
                Toast.makeText(requireContext(), "Питомец сохранён", Toast.LENGTH_SHORT).show()
                clearForm()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Ошибка: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun clearForm() {
        with(binding) {
            editType.text?.clear()
            editDescription.text?.clear()
            editDeposit.text?.clear()
            editLocation.text?.clear()
            editFullPrice.text?.clear()
            imagePreview.setImageURI(null)
            selectedImageUri = null
            criteriaContainer.removeAllViews()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
