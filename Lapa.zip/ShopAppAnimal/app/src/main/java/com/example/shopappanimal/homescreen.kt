package com.example.shopappanimal

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class homescreen : AppCompatActivity() {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_homescreen)

        val currentUser = auth.currentUser

        if (currentUser != null) {
            // Пользователь есть
            Log.d("Homescreen", "Пользователь авторизован: ${currentUser.email} (UID: ${currentUser.uid})")
            startActivity(Intent(this, MainActivity::class.java))
        } else {
            // Пользователь НЕ авторизован
            Log.d("Homescreen", "Пользователь не авторизован.")
            startActivity(Intent(this, Login::class.java))
        }

        finish()
    }
}
