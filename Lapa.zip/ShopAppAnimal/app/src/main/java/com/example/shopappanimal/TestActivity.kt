package com.example.shopappanimal

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.content.Context
import android.util.Log
import com.google.gson.Gson
import com.google.firebase.firestore.FirebaseFirestore
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import androidx.appcompat.app.AlertDialog
import android.widget.EditText
import android.widget.ImageButton
import com.bumptech.glide.Glide


class TestActivity : AppCompatActivity() {
    private lateinit var questionTextView: TextView
    private lateinit var optionsRadioGroup: RadioGroup
    private lateinit var submitButton: Button
    private lateinit var recommendationsLayout: LinearLayout
    private lateinit var takeRecommendedPetButton: Button
    private lateinit var goToMainPageButton: Button
    private lateinit var topUpBalanceButton: Button
    private lateinit var balanceText: TextView


    private var questions = listOf<Question>()
    private var currentQuestionIndex = 0
    private var userAnswers = mutableListOf<String>()
    private var selectedAnimalCategory: String? = null
    private var selectedPet: PetRecommendation? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test)

        balanceText = findViewById(R.id.balanceText)
        topUpBalanceButton = findViewById(R.id.topUpBalanceButton)

        loadUserBalance()

        questionTextView = findViewById(R.id.questionTextView)
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup)
        submitButton = findViewById(R.id.submitButton)
        recommendationsLayout = findViewById(R.id.recommendationsLayout)
        goToMainPageButton = findViewById(R.id.goToMainPageButton)

        goToMainPageButton.visibility = View.GONE

        loadInitialQuestions()
        displayQuestion()

        topUpBalanceButton = findViewById(R.id.topUpBalanceButton)
        topUpBalanceButton.visibility = View.GONE

        topUpBalanceButton.setOnClickListener {
            val editText = EditText(this)
            editText.inputType = android.text.InputType.TYPE_CLASS_NUMBER

            AlertDialog.Builder(this)
                .setTitle("Введите сумму пополнения")
                .setView(editText)
                .setPositiveButton("Пополнить") { _, _ ->
                    val input = editText.text.toString().toDoubleOrNull()
                    if (input != null && input > 0) {
                        val prefs = getSharedPreferences("IN", Context.MODE_PRIVATE)
                        val userId = prefs.getString("ID", null)
                        if (userId != null) {
                            val db = Firebase.firestore
                            db.collection("users").document(userId)
                                .update("balance", FieldValue.increment(input))
                                .addOnSuccessListener {
                                    Toast.makeText(this, "Баланс пополнен на $input₽", Toast.LENGTH_SHORT).show()
                                    loadUserBalance()
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this, "Ошибка при пополнении", Toast.LENGTH_SHORT).show()
                                }
                        }
                    } else {
                        Toast.makeText(this, "Некорректная сумма", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Отмена", null)
                .show()
        }

        submitButton.isEnabled = false

        optionsRadioGroup.setOnCheckedChangeListener { _, _ ->
            submitButton.isEnabled = true
        }


        submitButton.setOnClickListener {
            val selectedOptionId = optionsRadioGroup.checkedRadioButtonId
            if (selectedOptionId != -1) {
                val selectedOption = findViewById<RadioButton>(selectedOptionId)?.text?.toString()
                if (selectedOption != null) {
                    userAnswers.add(selectedOption)
                    currentQuestionIndex++

                    if (currentQuestionIndex < questions.size) {
                        displayQuestion()
                    } else {
                        if (selectedAnimalCategory == null) {
                            determineAnimalCategory()
                        } else {
                            showBestRecommendations(userAnswers)
                        }
                    }
                } else {
                    Toast.makeText(this, "Ошибка выбора", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Пожалуйста, выберите", Toast.LENGTH_SHORT).show()
            }
        }

        goToMainPageButton.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun loadUserBalance() {
        val prefs = getSharedPreferences("IN", Context.MODE_PRIVATE)
        val userId = prefs.getString("ID", null)

        if (userId != null) {
            val db = Firebase.firestore
            db.collection("users").document(userId)
                .get()
                .addOnSuccessListener { document ->
                    val balance = document.getDouble("balance") ?: 0.0
                    balanceText.text = "Баланс: ${balance.toInt()}₽"
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Не удалось загрузить баланс", Toast.LENGTH_SHORT).show()
                }
        }
    }


    private fun loadInitialQuestions() {
        questions = listOf(
            Question("Какого питомца вы хотите?", listOf("Собаки", "Кошки", "Грызуны", "Птицы", "Рыбы"))
        )
    }

    private fun determineAnimalCategory() {
        if (userAnswers.isNotEmpty()) {
            selectedAnimalCategory = userAnswers[0]
            loadSpecificQuestions(selectedAnimalCategory!!)
            currentQuestionIndex = 0
            userAnswers.clear()
            displayQuestion()
        }
    }

    private fun displayQuestion() {
        submitButton.isEnabled = false
        val currentQuestion = questions.getOrNull(currentQuestionIndex) ?: return
        questionTextView.text = currentQuestion.questionText
        optionsRadioGroup.removeAllViews()
        currentQuestion.options.forEach { option ->
            val radioButton = RadioButton(this)
            radioButton.text = option
            optionsRadioGroup.addView(radioButton)
        }
    }


    private fun loadSpecificQuestions(category: String) {
        questions = when (category) {
            "Собаки" -> listOf(
                Question("Какой уровень активности вам подходит?", listOf("Высокий", "Средний", "Низкий")),
                Question("Какой размер собаки вам удобен?", listOf("Маленький", "Средний", "Большой")),
                Question("Есть ли у вас аллергия на шерсть?", listOf("Да", "Нет")),
                Question("Готовы ли вы уделять время дрессировке?", listOf("Да", "Нет")),
                Question("У вас есть маленькие дети?", listOf("Да", "Нет")),
                Question("Нужна ли вам охранная собака?", listOf("Да", "Нет"))
            )
            "Кошки" -> listOf(
                Question("Какой уровень активности вам подходит?", listOf("Игривая", "Спокойная")),
                Question("Какой тип шерсти вы предпочитаете?", listOf("Короткая", "Длинная", "Гипоаллергенная")),
                Question("Есть ли у вас аллергия на шерсть?", listOf("Да", "Нет")),
                Question("Нуждается ли кошка в частом внимании?", listOf("Да", "Нет")),
                Question("Насколько важно для вас взаимодействие с питомцем?", listOf("Очень важно", "Не обязательно"))
            )
            "Грызуны" -> listOf(
                Question("Какой размер питомца вы хотите?", listOf("Маленький", "Средний")),
                Question("Какой тип ухода вам подходит?", listOf("Минимальный", "Средний")),
                Question("Насколько важно для вас взаимодействие с питомцем?", listOf("Очень важно", "Не обязательно"))
            )
            "Птицы" -> listOf(
                Question("Какой размер птицы вы хотите?", listOf("Маленькая", "Средняя", "Большая")),
                Question("Какой уровень шума вам комфортен?", listOf("Тихая", "Средний уровень", "Громкая"))
            )
            "Рыбы" -> listOf(
                Question("Какая сложность ухода вам подходит?", listOf("Простая", "Средняя", "Сложная")),
                Question("Какой размер аквариума у вас?", listOf("Маленький", "Средний", "Большой"))
            )
            else -> emptyList()
        }
    }

    private fun showBestRecommendations(criteria: List<String>) {
        // 1. Скрываем интерфейс вопросов
        submitButton.visibility = View.GONE
        questionTextView.visibility = View.GONE
        optionsRadioGroup.visibility = View.GONE

        val category = selectedAnimalCategory ?: return
        recommendationsLayout.removeAllViews()

        val allergyIndex = when (category) {
            "Собаки", "Кошки" -> 2
            else               -> -1
        }
        val hasAllergy = allergyIndex in criteria.indices && criteria[allergyIndex] == "Да"
        val wantsHypo = criteria.contains("Гипоаллергенная")
        val needHypo = hasAllergy || wantsHypo

        FirebaseFirestore.getInstance()
            .collection("pets")
            .whereEqualTo("category", category)
            .get()
            .addOnSuccessListener { docs ->
                // Собираем список Pet + score
                val scored = docs.mapNotNull { doc ->
                    val critList = (doc.get("criteria") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    var score = critList.count { criteria.contains(it) }
                    if (needHypo && critList.contains("Гипоаллергенная")) {
                        score += criteria.size
                    }
                    val status = doc.getString("status")?.trim() ?: ""
                    val pet = PetRecommendation(
                        petId      = doc.id,
                        type       = doc.getString("type") ?: "",
                        category   = category,
                        description= doc.getString("description") ?: "",
                        imageUrl = doc.getString("imageUrl") ?: "",
                        imageRes = 0,
                        criteria   = critList,
                        deposit    = doc.getString("deposit") ?: "",
                        location   = doc.getString("location") ?: "",
                        fullPrice  = doc.getString("fullPrice") ?: "",
                        status     = status
                    )
                    pet to score
                }

                // Фильтруем свободных
                val free = scored.filter { it.first.status.equals("Ожидает", ignoreCase = true) }
                val idealScore = criteria.size + if (needHypo) criteria.size else 0

                // Объявляем переменные заранее
                val chosenPet: PetRecommendation
                val headerText: String

                when {
                    // 1) Есть идеальные свободные
                    free.any { it.second >= idealScore } -> {
                        headerText = "Мы рекомендуем вам:"
                        chosenPet = free.first { it.second >= idealScore }.first
                    }
                    // 2) Есть свободные, но не идеальные
                    free.isNotEmpty() -> {
                        headerText = "Мы рекомендуем вам:"
                        chosenPet = free.maxByOrNull { it.second }!!.first
                    }
                    // 3) Нет свободных, но в целом есть питомцы
                    scored.isNotEmpty() -> {
                        headerText = "Подходящих свободных нет, но можем предложить:"
                        chosenPet = scored.maxByOrNull { it.second }!!.first
                    }
                    // 4) Совсем нет питомцев
                    else -> {
                        recommendationsLayout.addView(TextView(this).apply {
                            text = "К сожалению, нет питомцев в категории \"$category\"."
                        })
                        goToMainPageButton.visibility = View.VISIBLE
                        takeRecommendedPetButton.visibility = View.GONE
                        return@addOnSuccessListener
                    }
                }

                // Показываем единственного выбранного питомца
                displayPetRecommendation(chosenPet, headerText)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Ошибка загрузки питомцев", Toast.LENGTH_SHORT).show()
            }
    }



    private fun displayPetRecommendation(pet: PetRecommendation, recommendText: String) {
        // 1) Шапка с текстом рекомендации
        val header = layoutInflater.inflate(
            R.layout.item_recommendation_header,
            recommendationsLayout,
            false
        )
        header.findViewById<TextView>(R.id.recommendTextView).text = recommendText
        header.findViewById<TextView>(R.id.petTypeTextView).text = pet.type
        recommendationsLayout.addView(header)

        // 2) Инфлейтим саму карточку
        val petCard = layoutInflater.inflate(
            R.layout.item_pet_recommendation,
            recommendationsLayout,
            false
        )

        // 3) Находим нужные View внутри карточки
        val cardContainer   = petCard.findViewById<androidx.cardview.widget.CardView>(R.id.cardContainer)
        val imageView       = petCard.findViewById<ImageView>(R.id.petImageView)
        val typeView        = petCard.findViewById<TextView>(R.id.petTypeTextView)
        val descView        = petCard.findViewById<TextView>(R.id.petDescriptionTextView)
        val locationView    = petCard.findViewById<TextView>(R.id.locationTextView)
        val statusView      = petCard.findViewById<TextView>(R.id.petStatusTextView)
        val fullView        = petCard.findViewById<TextView>(R.id.fullPriceTextView)
        val depositView     = petCard.findViewById<TextView>(R.id.depositPriceTextView)
        val addBtn          = petCard.findViewById<Button>(R.id.addButton)
        val deleteBtn       = petCard.findViewById<Button>(R.id.deleteButton)
        val favoriteBtn     = petCard.findViewById<ImageButton>(R.id.favoriteButton)

        // 4) Заполняем данные
        Glide.with(this)
            .load(pet.imageUrl)
            .placeholder(R.drawable.zagruzka) // (опционально) Заглушка
            .error(R.drawable.zagruzka)             // (опционально) При ошибке
            .into(imageView)

        typeView.text      = pet.type
        descView.text      = pet.description
        locationView.text  = "Местоположение: ${pet.location}"
        statusView.text    = "Статус: ${pet.status}"
        fullView.text      = "Полная цена: ${pet.fullPrice}₽"
        depositView.text   = "Предоплата: ${pet.deposit}₽"


        addBtn.visibility = View.VISIBLE
        addBtn.text = "Купить"
        addBtn.setOnClickListener {
            val petToBuy = pet // берём конкретного pet из параметра метода

            val inPrefs = getSharedPreferences("IN", Context.MODE_PRIVATE)
            val uid = inPrefs.getString("ID", null)
            if (uid == null) {
                Toast.makeText(this, "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val db = Firebase.firestore
            val depositAmount = petToBuy.deposit.toDoubleOrNull()?.toLong() ?: 0L

            db.collection("users").document(uid).get().addOnSuccessListener { userDoc ->
                val balance = userDoc.getDouble("balance")?.toLong() ?: 0L
                if (balance < depositAmount) {
                    Toast.makeText(this, "Недостаточно средств", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                db.runTransaction { tx ->
                    tx.update(db.collection("users").document(uid), "balance", balance - depositAmount)
                }.addOnSuccessListener {
                    val req = hashMapOf(
                        "userId" to uid,
                        "petId" to petToBuy.petId,
                        "status" to "ожидает связи",
                        "timestamp" to FieldValue.serverTimestamp()
                    )
                    db.collection("petRequests").add(req)

                    db.collection("pets").document(petToBuy.petId)
                        .update("status", "ожидает связи")

                    val myPetsPrefs = getSharedPreferences("MyPetsPrefs", Context.MODE_PRIVATE)
                    val gson = Gson()
                    val set = myPetsPrefs.getStringSet("my_pets", emptySet())!!.toMutableSet()
                    set.add(gson.toJson(petToBuy))
                    myPetsPrefs.edit().putStringSet("my_pets", set).apply()

                    Toast.makeText(this, "${petToBuy.type} добавлен в ваши животцы!", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this, MainActivity::class.java)
                    intent.putExtra("open_my_pets", true)
                    startActivity(intent)
                    finish()
                }.addOnFailureListener {
                    Toast.makeText(this, "Ошибка при списании средств", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Ошибка проверки баланса", Toast.LENGTH_SHORT).show()
            }
        }

        // 5) Скрываем внутри-кнопки, т.к. в TestActivity используем внешние
        deleteBtn.visibility = View.GONE

        // 6) Настраиваем кнопку «В избранное»
        favoriteBtn.visibility = View.VISIBLE
        favoriteBtn.setOnClickListener {
            val uid = getSharedPreferences("IN", Context.MODE_PRIVATE)
                .getString("ID", null)
            if (uid == null) {
                Toast.makeText(this, "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Firebase.firestore.collection("favorites")
                .add(mapOf(
                    "userId"    to uid,
                    "petId"     to pet.petId,
                    "timestamp" to FieldValue.serverTimestamp()
                ))
                .addOnSuccessListener {
                    Toast.makeText(this, "Добавлено в избранное", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Ошибка при добавлении в избранное", Toast.LENGTH_SHORT).show()
                }
        }

        // 7) Скрываем детали до клика по карточке
        descView.visibility     = View.GONE
        locationView.visibility = View.GONE

        // 8) Обработчик клика — переключаем видимость деталей
        cardContainer.setOnClickListener {
            val newVis = if (descView.visibility == View.GONE) View.VISIBLE else View.GONE
            descView.visibility     = newVis
            locationView.visibility = newVis
        }

        // 9) Добавляем карточку в контейнер
        recommendationsLayout.addView(petCard)

        goToMainPageButton.visibility       = View.VISIBLE
        topUpBalanceButton.visibility       = View.VISIBLE
    }
}
