package com.example.shopappanimal

import java.io.Serializable

data class PetRecommendation(
    var petId: String = "",
    var type: String = "",
    var category: String = "",
    var description: String = "",
    var imageUrl: String = "", // ✅ URL изображения из cloudinary
    var imageRes: Int = 0,
    var criteria: List<String> = emptyList(),
    var deposit: String = "",
    var location: String = "",
    var fullPrice: String = "",
    var status: String = "",
    var isExpanded: Boolean = false,
    var note: String? = null, // например, если ожидается доплата от пользователя
    val ownerId: String = ""
) : Serializable
