package com.example.shopappanimal

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore

class PetAdapter(
    private var pets: MutableList<PetRecommendation>,
    private val onAddClick: (PetRecommendation) -> Unit,
    private val onFavoriteClick: (PetRecommendation) -> Unit,
    private val isInFavorites: Boolean = false,
    private val isAdmin: Boolean = false
) : RecyclerView.Adapter<PetAdapter.PetViewHolder>() {

    private lateinit var recyclerView: RecyclerView

    inner class PetViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val image: ImageView = itemView.findViewById(R.id.petImageView)
        private val desc: TextView = itemView.findViewById(R.id.petDescriptionTextView)
        private val type: TextView = itemView.findViewById(R.id.petTypeTextView)
        private val depo: TextView = itemView.findViewById(R.id.depositPriceTextView)
        private val full: TextView = itemView.findViewById(R.id.fullPriceTextView)
        private val location: TextView = itemView.findViewById(R.id.locationTextView)
        private val addBtn: Button = itemView.findViewById(R.id.addButton)
        private val favoriteBtn: ImageButton = itemView.findViewById(R.id.favoriteButton)
        val deleteBtn: Button = itemView.findViewById(R.id.deleteButton)
        private val note: TextView = itemView.findViewById(R.id.noteTextView)
        private val editBtn: ImageButton = itemView.findViewById(R.id.editButton)

        fun bind(pet: PetRecommendation) {
            // Загрузка изображения с помощью Glide или установка заглушки
            if (pet.imageUrl.isNotBlank()) {
                Glide.with(itemView)
                    .load(pet.imageUrl)
                    .placeholder(R.drawable.zagruzka)
                    .error(R.drawable.zagruzka)
                    .into(image)
            } else {
                image.setImageResource(android.R.drawable.ic_menu_report_image)
            }

            type.text = pet.type
            desc.text = pet.description
            location.text = "Местоположение: ${pet.location}"
            full.text = "Цена: ${pet.fullPrice}₽"
            depo.text = "Предоплата: ${pet.deposit}₽"

            note.text = pet.note?.takeIf { it.isNotBlank() }?.let { "Примечание: $it" } ?: ""
            note.visibility = if (!pet.note.isNullOrBlank() && pet.isExpanded) View.VISIBLE else View.GONE

            val detailsVisibility = if (pet.isExpanded) View.VISIBLE else View.GONE
            desc.visibility = detailsVisibility
            location.visibility = detailsVisibility

            itemView.setOnClickListener {
                pet.isExpanded = !pet.isExpanded
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    notifyItemChanged(pos)
                }
            }

            addBtn.setOnClickListener { onAddClick(pet) }

            if (isInFavorites) {
                favoriteBtn.visibility = View.GONE
                deleteBtn.visibility = View.VISIBLE
                deleteBtn.setOnClickListener { onFavoriteClick(pet) }
            } else {
                favoriteBtn.visibility = View.VISIBLE
                favoriteBtn.setOnClickListener { onFavoriteClick(pet) }
                deleteBtn.visibility = View.GONE
            }

            editBtn.visibility = if (isAdmin) View.VISIBLE else View.GONE
            editBtn.setOnClickListener {
                if (isAdmin) showEditDialog(pet)
            }
        }

        private fun showEditDialog(pet: PetRecommendation) {
            val context = itemView.context
            val dialogView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_edit_pet, null)

            val nameEt = dialogView.findViewById<EditText>(R.id.nameEditText)
            val descEt = dialogView.findViewById<EditText>(R.id.descEditText)
            val locEt  = dialogView.findViewById<EditText>(R.id.locEditText)
            val fullEt = dialogView.findViewById<EditText>(R.id.fullPriceEditText)
            val depEt  = dialogView.findViewById<EditText>(R.id.depositEditText)

            nameEt.setText(pet.type)
            descEt.setText(pet.description)
            locEt.setText(pet.location)
            fullEt.setText(pet.fullPrice.toString())
            depEt.setText(pet.deposit.toString())

            AlertDialog.Builder(context)
                .setTitle("Редактировать питомца")
                .setView(dialogView)
                .setPositiveButton("Сохранить") { _, _ ->
                    val updates = mapOf<String, Any>(
                        "type" to nameEt.text.toString(),
                        "description" to descEt.text.toString(),
                        "location" to locEt.text.toString(),
                        "fullPrice" to fullEt.text.toString(),
                        "deposit" to depEt.text.toString()
                    )
                    savePetChanges(pet.petId, updates)
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
    }

    private fun savePetChanges(petId: String?, updates: Map<String, Any>) {
        if (petId == null) {
            Toast.makeText(recyclerView.context, "Ошибка: ID питомца не найден", Toast.LENGTH_SHORT).show()
            return
        }
        FirebaseFirestore.getInstance()
            .collection("pets").document(petId)
            .update(updates)
            .addOnSuccessListener {
                Toast.makeText(recyclerView.context, "Питомец обновлён", Toast.LENGTH_SHORT).show()
                val index = pets.indexOfFirst { it.petId == petId }
                if (index != -1) {
                    val old = pets[index]
                    pets[index] = old.copy(
                        type = updates["type"] as? String ?: old.type,
                        description = updates["description"] as? String ?: old.description,
                        location = updates["location"] as? String ?: old.location,
                        fullPrice = updates["fullPrice"] as? String ?: old.fullPrice,
                        deposit = updates["deposit"] as? String ?: old.deposit
                    )
                    notifyItemChanged(index)
                }
            }
            .addOnFailureListener {
                Toast.makeText(recyclerView.context, "Ошибка: ${it.message}", Toast.LENGTH_LONG).show()
            }
    }

    override fun onAttachedToRecyclerView(rv: RecyclerView) {
        super.onAttachedToRecyclerView(rv)
        recyclerView = rv
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PetViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_pet_recommendation, parent, false)
        return PetViewHolder(view)
    }

    override fun onBindViewHolder(holder: PetViewHolder, position: Int) {
        holder.bind(pets[position])
    }

    override fun getItemCount(): Int = pets.size

    fun updatePets(newPets: MutableList<PetRecommendation>) {
        pets = newPets
        notifyDataSetChanged()
    }
}
