package com.example.shopappanimal.fragments

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shopappanimal.PetAdapter
import com.example.shopappanimal.PetRecommendation
import com.example.shopappanimal.R
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class HomeFragment : Fragment(R.layout.activity_home_fragment) {

    private lateinit var searchEditText: EditText
    private lateinit var categorySpinner: Spinner
    private lateinit var recyclerView: RecyclerView
    private lateinit var petAdapter: PetAdapter
    private lateinit var progressBar: View

    private val allPets     = mutableListOf<PetRecommendation>()
    private val visiblePets = mutableListOf<PetRecommendation>()
    private var selectedCategory = "Все"

    private val db = Firebase.firestore
    private var userId: String? = null
    private var isAdmin = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.activity_home_fragment, container, false)

        searchEditText = view.findViewById(R.id.searchEditText)
        categorySpinner = view.findViewById(R.id.categorySpinner)
        recyclerView = view.findViewById(R.id.recyclerViewPets)
        progressBar = view.findViewById(R.id.progressBar)

        // Инициализация RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Получаем ID и admin-флаг из SharedPreferences "IN"
        requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE).apply {
            userId = getString("ID", null)
            isAdmin = (getString("phone", "") == "123456789")
        }

        // После получения isAdmin создаём адаптер
        petAdapter = PetAdapter(
            pets = visiblePets,
            onAddClick = { pet -> addPetToMyPets(pet) },
            onFavoriteClick = { pet -> addPetToFavorites(pet) },
            isInFavorites = false,
            isAdmin = isAdmin
        )
        recyclerView.adapter = petAdapter

        setupSearch()
        setupCategorySpinner()
        loadPetsFromFirestore()
        return view
    }


    fun addPetToFavorites(pet: PetRecommendation) {
        val uid = requireContext()
            .getSharedPreferences("IN", Context.MODE_PRIVATE)
            .getString("ID", null) ?: return

        db.collection("favorites")
            .add(mapOf(
                "userId"    to uid,
                "petId"     to pet.petId,
                "timestamp" to FieldValue.serverTimestamp()
            ))
            .addOnSuccessListener {
                Toast.makeText(context, "В избранном", Toast.LENGTH_SHORT).show()
            }
    }




    private fun setupSearch() {
        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filterPets()
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun setupCategorySpinner() {
        val cats = listOf("Все","Собаки","Кошки","Птицы","Рыбы","Грызуны")
        categorySpinner.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            cats
        )
        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, pos: Int, id: Long
            ) {
                selectedCategory = cats[pos]
                filterPets()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun loadPetsFromFirestore() {
        progressBar.visibility = View.VISIBLE // Показать индикатор загрузки

        db.collection("pets").get().addOnSuccessListener { petsSnap ->
            db.collection("petRequests").get().addOnSuccessListener { reqSnap ->
                val requestedIds = reqSnap.documents.mapNotNull { it.getString("petId") }
                allPets.clear()
                petsSnap.documents.forEach { doc ->
                    doc.toObject(PetRecommendation::class.java)
                        ?.copy(petId = doc.id)
                        ?.let { pet ->
                            if (pet.petId !in requestedIds && pet.status == "Ожидает") {
                                allPets.add(pet)
                            }
                        }
                }
                filterPets()
                progressBar.visibility = View.GONE // Скрыть после загрузки
            }.addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка загрузки заявок", Toast.LENGTH_SHORT).show()
                progressBar.visibility = View.GONE
            }
        }.addOnFailureListener {
            Toast.makeText(requireContext(), "Ошибка загрузки питомцев", Toast.LENGTH_SHORT).show()
            progressBar.visibility = View.GONE
        }
    }

    private fun filterPets() {
        val q = searchEditText.text.toString().lowercase()
        visiblePets.clear()
        visiblePets.addAll(allPets.filter { pet ->
            (selectedCategory == "Все" || pet.category == selectedCategory)
                    && (pet.type.lowercase().contains(q) || pet.description.lowercase().contains(q))
        })
        petAdapter.updatePets(visiblePets)
    }

    private fun addPetToMyPets(pet: PetRecommendation) {
        userId?.let { uid ->
            val pre = pet.deposit.toDoubleOrNull() ?: 0.0
            db.collection("users").document(uid).get().addOnSuccessListener { doc ->
                val bal = doc.getDouble("balance") ?: 0.0
                if (bal >= pre) {
                    // транзакция списания
                    db.runTransaction { tx ->
                        tx.update(db.collection("users").document(uid), "balance", bal - pre)
                    }.addOnSuccessListener {
                        Firebase.firestore.collection("favorites")
                            .whereEqualTo("petId", pet.petId)
                            .get()
                            .addOnSuccessListener { snap ->
                                snap.documents.forEach { it.reference.delete() }
                            }
                        // создаём запрос
                        val req = hashMapOf(
                            "userId" to uid,
                            "petId"  to pet.petId,
                            "status" to "ожидает связи",
                            "timestamp" to FieldValue.serverTimestamp()
                        )
                        db.collection("petRequests").add(req)
                        db.collection("pets").document(pet.petId)
                            .update("status", "ожидает связи")

                        // **1. Сохраняем в SharedPreferences**
                        val prefs = requireContext()
                            .getSharedPreferences("MyPetsPrefs", Context.MODE_PRIVATE)
                        val gson = com.google.gson.Gson()
                        // читаем текущее множество JSON
                        val set = prefs.getStringSet("my_pets", emptySet())!!
                            .toMutableSet()
                        // добавляем новый питомец в виде JSON
                        set.add(gson.toJson(pet))
                        prefs.edit().putStringSet("my_pets", set).apply()

                        Toast.makeText(
                            requireContext(),
                            "${pet.type} добавлен в мои животные",
                            Toast.LENGTH_SHORT
                        ).show()
                        // обновляем UI
                        allPets.remove(pet)
                        filterPets()
                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Недостаточно средств",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } ?: run {
            Toast.makeText(
                requireContext(),
                "Пользователь не авторизован",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

}
