package com.example.shopappanimal.fragments

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.Log
import android.view.View
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.example.shopappanimal.Login
import com.example.shopappanimal.R
import com.google.firebase.firestore.FirebaseFirestore
import android.net.Uri

class ProfileFragment : Fragment(R.layout.activity_profile_fragment) {

    private lateinit var usernameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var editProfileButton: Button
    private lateinit var logoutButton: Button
    private lateinit var balanceTextView: TextView
    private lateinit var addBalanceButton: Button

    @SuppressLint("SetTextI18n")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sharedPrefs = requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)

        usernameTextView = view.findViewById(R.id.usernameTextView)
        emailTextView = view.findViewById(R.id.emailTextView)
        editProfileButton = view.findViewById(R.id.editProfileButton)
        logoutButton = view.findViewById(R.id.logoutButton)
        balanceTextView = view.findViewById(R.id.balanceText)
        addBalanceButton = view.findViewById(R.id.addBalanceButton)
        val supportPhoneTextView: TextView = view.findViewById(R.id.supportPhoneTextView)

        showUserDataFromLocal(sharedPrefs)
        showBalanceFromFirestore(view, sharedPrefs)

        editProfileButton.setOnClickListener { editProfile() }
        logoutButton.setOnClickListener { logout() }
        addBalanceButton.setOnClickListener { showAddBalanceDialog(sharedPrefs) }

        supportPhoneTextView.setOnClickListener {
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:+78001234567")
            }
            startActivity(intent)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showUserDataFromLocal(sharedPrefs: android.content.SharedPreferences) {
        val name = sharedPrefs.getString("name", "Имя не указано")
        val phone = sharedPrefs.getString("phone", "Телефон не указан")
        usernameTextView.text = name
        emailTextView.text = phone
    }

    private fun showBalanceFromFirestore(view: View, sharedPrefs: android.content.SharedPreferences) {
        val balanceText: TextView = view.findViewById(R.id.balanceText)
        val userId = sharedPrefs.getString("ID", null)

        if (userId != null) {
            val db = FirebaseFirestore.getInstance()
            db.collection("users").document(userId)
                .addSnapshotListener { snapshot, e ->
                    if (e != null) {
                        Log.w("Firestore", "Ошибка при получении баланса", e)
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val balanceAny = snapshot.get("balance")
                        val balance = when (balanceAny) {
                            is Number -> balanceAny.toDouble()
                            is String -> balanceAny.toDoubleOrNull() ?: 0.0
                            else -> 0.0
                        }
                        balanceText.text = "Баланс: ${balance.toInt()}₽"
                    } else {
                        balanceText.text = "Баланс: не найден"
                    }
                }
        } else {
            balanceText.text = "Баланс: не найден"
            Log.e("ProfileFragment", "UID не найден в SharedPreferences")
        }
    }

    private fun showAddBalanceDialog(sharedPrefs: android.content.SharedPreferences) {
        val editText = EditText(requireContext()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Введите сумму пополнения"
        }

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Пополнить счёт")
            .setView(editText)
            .setPositiveButton("ОК") { _, _ ->
                val input = editText.text.toString()
                val amount = input.toIntOrNull()
                if (amount != null && amount > 0) {
                    addBalance(amount, sharedPrefs)
                } else {
                    Toast.makeText(requireContext(), "Введите корректную сумму", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .create()
            .show()
    }

    private fun addBalance(amount: Int, sharedPrefs: android.content.SharedPreferences) {
        val uid = sharedPrefs.getString("ID", null)
        if (uid != null) {
            val db = FirebaseFirestore.getInstance()
            val userDocRef = db.collection("users").document(uid)

            db.runTransaction { transaction ->
                val snapshot = transaction.get(userDocRef)
                val currentBalance = snapshot.getDouble("balance") ?: 0.0
                val newBalance = currentBalance + amount
                transaction.update(userDocRef, "balance", newBalance)
                newBalance
            }.addOnSuccessListener { newBalance ->
                Toast.makeText(requireContext(), "Баланс пополнен на $amount₽", Toast.LENGTH_SHORT).show()
            }.addOnFailureListener { e ->
                Log.e("ProfileFragment", "Ошибка при обновлении баланса", e)
                Toast.makeText(requireContext(), "Ошибка при обновлении Firestore", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(requireContext(), "UID пользователя не найден", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editProfile() {
        parentFragmentManager.commit {
            replace(R.id.fragment_container, EditProfileFragment())
            addToBackStack(null)
        }
    }

    private fun logout() {
        requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE).edit().clear().apply()

        val intent = Intent(requireContext(), Login::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }

}
