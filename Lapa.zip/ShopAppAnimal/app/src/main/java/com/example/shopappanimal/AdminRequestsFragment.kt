package com.example.shopappanimal

import android.content.Context
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class AdminRequestsFragment : Fragment(R.layout.fragment_admin_requests) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: AdminRequestsAdapter
    private lateinit var emptyTextView: TextView

    private val db = Firebase.firestore
    private val requests = mutableListOf<PetRequestWithPet>()
    private val encryptionHelper = EncryptionHelper("G8BnK9Qfuntk9vl6")

    // Текущий пользователь из SharedPreferences
    private val prefs by lazy {
        requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)
    }
    private val currentUserId: String?
        get() = prefs.getString("ID", null)
    private val isAdmin: Boolean
        get() = prefs.getString("phone", "") == "123456789"

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerViewAdmin)
        emptyTextView = view.findViewById(R.id.emptyTextView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        adapter = AdminRequestsAdapter(requests,
            onStatusChange = { req, newStatus -> updateStatus(req, newStatus) },
            onDelete       = { req -> deleteRequest(req) }
        )
        recyclerView.adapter = adapter

        // Проверяем авторизацию
        if (currentUserId.isNullOrEmpty()) {
            Toast.makeText(requireContext(), "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
            emptyTextView.visibility = View.VISIBLE
            return
        }

        // Если админ — грузим все заявки, иначе только свои
        if (isAdmin) {
            loadAllRequests()
        } else {
            loadUserRequests()
        }
    }

    /** Для админа: все заявки */
    private fun loadAllRequests() {
        db.collection("petRequests")
            .get()
            .addOnSuccessListener { reqSnap ->
                if (reqSnap.isEmpty) {
                    showEmpty()
                    return@addOnSuccessListener
                }
                // Сначала соберём petId и userId
                val petIds  = reqSnap.documents.mapNotNull { it.getString("petId") }
                val userIds = reqSnap.documents.mapNotNull { it.getString("userId") }.toSet()

                // Загрузим всех питомцев
                db.collection("pets")
                    .whereIn(FieldPath.documentId(), petIds)
                    .get()
                    .addOnSuccessListener { petSnap ->
                        // Загрузим всех пользователей (чтобы расшифровать телефоны)
                        db.collection("users")
                            .whereIn(FieldPath.documentId(), userIds.toList())
                            .get()
                            .addOnSuccessListener { userSnap ->
                                val phoneMap = userSnap.documents.associate { doc ->
                                    val enc = doc.getString("phone") ?: ""
                                    val dec = try {
                                        encryptionHelper.decrypt(enc)
                                    } catch (e: Exception) {
                                        "ошибка"
                                    }
                                    doc.id to dec
                                }
                                // Соберём список заявок
                                requests.clear()
                                reqSnap.documents.forEach { doc ->
                                    val petId   = doc.getString("petId") ?: return@forEach
                                    val userId  = doc.getString("userId") ?: return@forEach
                                    val petDoc  = petSnap.documents.find { it.id == petId } ?: return@forEach
                                    val pet     = petDoc.toObject(PetRecommendation::class.java)
                                        ?.copy(petId = petId) ?: return@forEach
                                    val status  = doc.getString("status") ?: ""
                                    val phone   = phoneMap[userId] ?: ""
                                    requests.add(
                                        PetRequestWithPet(
                                            requestId  = doc.id,
                                            pet        = pet,
                                            userId     = userId,
                                            status     = status,
                                            buyerPhone = phone
                                        )
                                    )
                                }
                                adapter.updateRequests(requests)
                                emptyTextView.visibility = View.GONE
                            }
                    }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка загрузки заявок", Toast.LENGTH_SHORT).show()
            }
    }

    /** Для обычного пользователя: заявки только на его питомцев */
    private fun loadUserRequests() {
        val ownerId = currentUserId ?: return

        // Сначала получим все питомцы текущего пользователя
        db.collection("pets")
            .whereEqualTo("ownerId", ownerId)
            .get()
            .addOnSuccessListener { petSnap ->
                if (petSnap.isEmpty) {
                    showEmpty()
                    return@addOnSuccessListener
                }
                val ownedIds = petSnap.documents.map { it.id }

                // Получаем заявки только по этим petId
                db.collection("petRequests")
                    .whereIn("petId", ownedIds)
                    .get()
                    .addOnSuccessListener { reqSnap ->
                        if (reqSnap.isEmpty) {
                            showEmpty()
                            return@addOnSuccessListener
                        }
                        // как в админской версии — получаем телефоны
                        val userIds = reqSnap.documents.mapNotNull { it.getString("userId") }.toSet()
                        db.collection("users")
                            .whereIn(FieldPath.documentId(), userIds.toList())
                            .get()
                            .addOnSuccessListener { userSnap ->
                                val phoneMap = userSnap.documents.associate { doc ->
                                    val enc = doc.getString("phone") ?: ""
                                    val dec = try {
                                        encryptionHelper.decrypt(enc)
                                    } catch (e: Exception) {
                                        "ошибка"
                                    }
                                    doc.id to dec
                                }
                                requests.clear()
                                reqSnap.documents.forEach { doc ->
                                    val petId  = doc.getString("petId") ?: return@forEach
                                    val userId = doc.getString("userId") ?: return@forEach
                                    val petDoc = petSnap.documents.find { it.id == petId } ?: return@forEach
                                    val pet    = petDoc.toObject(PetRecommendation::class.java)
                                        ?.copy(petId = petId) ?: return@forEach
                                    val status = doc.getString("status") ?: ""
                                    val phone  = phoneMap[userId] ?: ""
                                    requests.add(
                                        PetRequestWithPet(
                                            requestId  = doc.id,
                                            pet        = pet,
                                            userId     = userId,
                                            status     = status,
                                            buyerPhone = phone
                                        )
                                    )
                                }
                                adapter.updateRequests(requests)
                                emptyTextView.visibility = View.GONE
                            }
                    }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка загрузки заявок", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showEmpty() {
        requests.clear()
        adapter.updateRequests(requests)
        emptyTextView.visibility = View.VISIBLE
    }

    private fun updateStatus(request: PetRequestWithPet, newStatus: String) {
        val petRef = db.collection("pets").document(request.pet.petId)
        val requestRef = db.collection("petRequests").document(request.requestId)
        val userRef = db.collection("users").document(request.userId)

        if (newStatus == "уже едет") {
            val fullPrice = request.pet.fullPrice.toDoubleOrNull() ?: 0.0
            val deposit = request.pet.deposit.toDoubleOrNull() ?: 0.0
            val remaining = fullPrice - deposit

            db.runTransaction { tx ->
                val userDoc = tx.get(userRef)
                val currentBalance = userDoc.getDouble("balance") ?: 0.0

                return@runTransaction if (currentBalance >= remaining) {
                    tx.update(userRef, "balance", currentBalance - remaining)
                    tx.update(requestRef, "status", newStatus)
                    tx.update(petRef, mapOf("status" to newStatus, "note" to ""))
                    null
                } else {
                    tx.update(petRef, "note", "Ожидается доплата от пользователя")
                    "Недостаточно средств у пользователя для завершения оплаты"
                }
            }.addOnSuccessListener { errorMessage ->
                if (errorMessage == null) {
                    Toast.makeText(requireContext(), "Статус обновлён, оплата завершена", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_LONG).show()
                }
                loadUserRequests()
            }.addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка транзакции: ${it.message}", Toast.LENGTH_SHORT).show()
            }
        } else {
            db.runBatch { batch ->
                batch.update(requestRef, "status", newStatus)
                batch.update(petRef, "status", newStatus)
            }.addOnSuccessListener {
                Toast.makeText(requireContext(), "Статус обновлён", Toast.LENGTH_SHORT).show()
                loadUserRequests()
            }
        }
    }

    private fun deleteRequest(request: PetRequestWithPet) {
        // Ссылки на документы
        val requestRef = db.collection("petRequests").document(request.requestId)
        val petRef     = db.collection("pets").document(request.pet.petId)

        // Сначала удаляем заявку
        requestRef.delete()
            .addOnSuccessListener {
                // После успешного удаления заявки — обновляем статус питомца
                petRef.update("status", "свободен")
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(),
                            "Заявка удалена, питомец снова свободен",
                            Toast.LENGTH_SHORT
                        ).show()
                        // Обновляем список после удаления
                        if (isAdmin) {
                            loadAllRequests()
                        } else {
                            loadUserRequests()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(requireContext(),
                            "Ошибка при обновлении статуса питомца: ${e.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(),
                    "Ошибка удаления заявки: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
    }
}
