package com.example.shopappanimal.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.shopappanimal.PetRecommendation
import com.example.shopappanimal.R
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.gson.Gson
import android.util.Log
import com.bumptech.glide.Glide


class MyPetsFragment : Fragment(R.layout.fragment_my_pets) {

    private lateinit var petsContainer: LinearLayout
    private val db = Firebase.firestore
    private val gson = Gson()

    private var userId: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        petsContainer = view.findViewById(R.id.petsContainer)

        userId = requireContext().getSharedPreferences("IN", Context.MODE_PRIVATE)
            .getString("ID", null)

        if (userId != null) {
            loadMyPets()
        } else {
            Toast.makeText(requireContext(), "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadMyPets(isAfterDelete: Boolean = false) {
        db.collection("petRequests")
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { requestSnap ->
                val petRequests = requestSnap.documents.mapNotNull { doc ->
                    val petId = doc.getString("petId") ?: return@mapNotNull null
                    val status = doc.getString("status") ?: "Ожидает"
                    Pair(petId, status)
                }

                if (petRequests.isEmpty()) {
                    petsContainer.removeAllViews()
                    if (!isAfterDelete) {
                        showNoPetsMessage()
                    }
                    return@addOnSuccessListener
                }

                val petIds = petRequests.map { it.first }

                db.collection("pets")
                    .whereIn(FieldPath.documentId(), petIds)
                    .get()
                    .addOnSuccessListener { petsSnap ->
                        val pets = petsSnap.documents.mapNotNull { doc ->
                            val pet = doc.toObject(PetRecommendation::class.java)?.copy(petId = doc.id)
                            pet?.let { p ->
                                val matchingRequest = petRequests.find { it.first == doc.id }
                                if (matchingRequest != null) {
                                    p.status = matchingRequest.second // Переопределяем статус из заявки
                                }
                                p
                            }
                        }.toMutableList()

                        if (isAdded) {
                        displayPets(pets)
                        }
                    }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка загрузки животных", Toast.LENGTH_SHORT).show()
            }
    }



    private fun displayPets(pets: MutableList<PetRecommendation>) {
        petsContainer.removeAllViews()

        if (pets.isEmpty()) {
            return
        }

        pets.forEach { pet ->
            val petView = LayoutInflater.from(requireContext()).inflate(R.layout.item_pet_recommendation, petsContainer, false)
            val image = petView.findViewById<android.widget.ImageView>(R.id.petImageView)
            val desc = petView.findViewById<android.widget.TextView>(R.id.petDescriptionTextView)
            val addBtn = petView.findViewById<android.widget.Button>(R.id.addButton)
            val delBtn = petView.findViewById<android.widget.Button>(R.id.deleteButton)
            val statusText = petView.findViewById<android.widget.TextView>(R.id.petStatusTextView)
            val prepaymentText = petView.findViewById<android.widget.TextView>(R.id.fullPriceTextView)
            val priceText = petView.findViewById<android.widget.TextView>(R.id.depositPriceTextView)
            val favoriteBtn = petView.findViewById<ImageButton>(R.id.favoriteButton)

            favoriteBtn.visibility = View.GONE
            favoriteBtn.setOnClickListener(null)

            val imageUrl = pet.imageUrl  // тут предполагается, что у PetRecommendation есть поле imageUrl типа String?

            if (!imageUrl.isNullOrEmpty()) {
                Glide.with(requireContext())
                    .load(imageUrl)
                    .placeholder(R.drawable.zagruzka) // картинка по умолчанию, пока грузится
                    .error(R.drawable.zagruzka)       // картинка, если ошибка загрузки
                    .into(image)
            } else {
                image.setImageResource(R.drawable.zagruzka)
            }

            favoriteBtn.visibility = View.GONE // <-- скрываем кнопку избранного
            favoriteBtn.setOnClickListener(null) // <-- на всякий случай отключаем клик

            // Отображение типа всегда
            petView.findViewById<android.widget.TextView>(R.id.petTypeTextView).text = pet.type

            statusText.text = "Статус: ${pet.status}"
            // Если статус "уже едет", показать "внесено", иначе показать полную цену
            if (pet.status == "уже едет" || pet.status == "дома") {
                priceText.text = "Цена: внесено"
            } else {
                priceText.text = "Цена: ${pet.fullPrice} ₽"
            }
            prepaymentText.text = "Предоплата: внесено"
            addBtn.visibility = View.GONE

            // скрываем кнопку удаления, если статус "уже едет" или "дома"
            if (pet.status == "уже едет" || pet.status == "дома") {
                delBtn.visibility = View.GONE
            } else {
                delBtn.visibility = View.VISIBLE
                delBtn.setOnClickListener { removePet(pet) }
            }
            desc.text = pet.description
            // Обработчик клика для развертывания/сворачивания
            petView.setOnClickListener {
                pet.isExpanded = !pet.isExpanded // Переключаем состояние
                Log.d("PetExpanded", "Pet expanded state: ${pet.isExpanded}") // Логируем изменение состояния

                // Обновляем видимость описания при клике
                val visibility = if (pet.isExpanded) View.VISIBLE else View.GONE
                desc.visibility = visibility
            }

            petsContainer.addView(petView)
        }
    }



    private fun removePet(pet: PetRecommendation) {
        db.collection("petRequests")
            .whereEqualTo("petId", pet.petId)
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { snapshot ->
                for (doc in snapshot.documents) {
                    doc.reference.delete()
                }

                db.collection("pets").document(pet.petId)
                    .update("status", "Ожидает")
                    .addOnSuccessListener {
                        Toast.makeText(requireContext(), "Питомец удален из заявок", Toast.LENGTH_SHORT).show()
                        loadMyPets(isAfterDelete = true)
                    }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Ошибка удаления", Toast.LENGTH_SHORT).show()
            }
    }


    private fun showNoPetsMessage() {
        val message = LayoutInflater.from(requireContext()).inflate(R.layout.item_no_pets_message, petsContainer, false)
        petsContainer.addView(message)
    }
}
