package com.example.shopappanimal

data class PetRequestWithPet(
    val requestId: String,
    val pet: PetRecommendation,
    val userId: String,
    val status: String,
    var buyerPhone: String? = ""
)