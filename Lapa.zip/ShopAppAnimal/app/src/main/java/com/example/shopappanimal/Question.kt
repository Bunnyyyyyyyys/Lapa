package com.example.shopappanimal

data class Question(
    val questionText: String,
    val options: List<String>
)