package com.example.shopappanimal.fragments

import android.content.Context
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.shopappanimal.PetAdapter
import com.example.shopappanimal.PetRecommendation
import com.example.shopappanimal.R
import com.google.firebase.firestore.FieldPath
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import android.widget.TextView

class FavoritesFragment : Fragment(R.layout.fragment_favorites) {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyTextView: TextView
    private lateinit var petAdapter: PetAdapter
    private val favoritePets = mutableListOf<PetRecommendation>()
    private val db = Firebase.firestore
    private var userId: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_favorites, container, false)

        recyclerView = view.findViewById(R.id.recyclerViewFavorites)
        emptyTextView = view.findViewById(R.id.emptyFavoritesTextView)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        petAdapter = PetAdapter(
            favoritePets,
            onAddClick = { pet -> addPetToMyPets(pet) },
            onFavoriteClick = { pet -> removePetFromFavorites(pet) },
            isInFavorites = true
        )
        recyclerView.adapter = petAdapter

        loadUserId()
        loadFavorites()

        return view
    }

    private fun loadUserId() {
        val prefs = requireContext()
            .getSharedPreferences("IN", Context.MODE_PRIVATE)
        userId = prefs.getString("ID", null)
    }

    fun loadFavorites() {
        val uid = userId ?: return

        db.collection("favorites")
            .whereEqualTo("userId", uid)
            .get()
            .addOnSuccessListener { snap ->
                val petIds = snap.documents.mapNotNull { it.getString("petId") }
                if (petIds.isEmpty()) {
                    favoritePets.clear()
                    updateUI()
                } else {
                    db.collection("pets")
                        .whereIn(FieldPath.documentId(), petIds)
                        .get()
                        .addOnSuccessListener { petsSnap ->
                            favoritePets.clear()
                            petsSnap.documents.forEach { d ->
                                d.toObject(PetRecommendation::class.java)
                                    ?.copy(petId = d.id)
                                    ?.let { favoritePets += it }
                            }
                            updateUI()
                        }
                }
            }
    }


    fun removePetFromFavorites(pet: PetRecommendation) {
        val uid = userId ?: return

        db.collection("favorites")
            .whereEqualTo("userId", uid)
            .whereEqualTo("petId", pet.petId)
            .get()
            .addOnSuccessListener { snap ->
                // удаляем все документы, соответствующие этому фильтру
                snap.documents.forEach { it.reference.delete() }
                loadFavorites()
            }
    }


    private fun addPetToMyPets(pet: PetRecommendation) {
        val uid = userId
        if (uid == null) {
            Toast.makeText(requireContext(),
                "Пользователь не авторизован",
                Toast.LENGTH_SHORT).show()
            return
        }

        val preDeposit = pet.deposit.toDoubleOrNull() ?: 0.0
        db.collection("users").document(uid).get().addOnSuccessListener { doc ->
            val balance = doc.getDouble("balance") ?: 0.0
            if (balance >= preDeposit) {
                db.runTransaction { tx ->
                    tx.update(db.collection("users").document(uid),
                        "balance", balance - preDeposit)
                }.addOnSuccessListener {
                    val req = mapOf(
                        "userId" to uid,
                        "petId" to pet.petId,
                        "status" to "ожидает связи",
                        "timestamp" to FieldValue.serverTimestamp()
                    )
                    db.collection("petRequests").add(req)
                    db.collection("pets").document(pet.petId)
                        .update("status", "ожидает связи")

                    // Удаляем из избранного у этого пользователя
                    db.collection("favorites")
                        .whereEqualTo("userId", uid)
                        .whereEqualTo("petId", pet.petId)
                        .get()
                        .addOnSuccessListener { snap ->
                            snap.documents.forEach { it.reference.delete() }
                        }


                    Toast.makeText(requireContext(),
                        "${pet.type} добавлен в мои животные",
                        Toast.LENGTH_SHORT).show()
                    loadFavorites()
                }
            } else {
                Toast.makeText(requireContext(),
                    "Недостаточно средств",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateUI() {
        if (favoritePets.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyTextView.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyTextView.visibility = View.GONE
            petAdapter.updatePets(favoritePets)
        }
    }
}
