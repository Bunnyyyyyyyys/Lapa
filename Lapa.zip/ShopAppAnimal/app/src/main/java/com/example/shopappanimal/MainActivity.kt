package com.example.shopappanimal

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.cloudinary.Cloudinary
import com.cloudinary.utils.ObjectUtils
import com.example.shopappanimal.fragments.*
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var bottomNavigation: BottomNavigationView

    private val PICK_IMAGE_REQUEST = 1
    private var selectedImageUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        WindowCompat.setDecorFitsSystemWindows(window, false)

        drawerLayout = findViewById(R.id.drawer_layout)
        navigationView = findViewById(R.id.navigation_view)
        bottomNavigation = findViewById(R.id.bottom_navigation)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
        ViewCompat.setOnApplyWindowInsetsListener(toolbar) { view, insets ->
            val statusBarInsets = insets.getInsets(WindowInsetsCompat.Type.statusBars())
            view.updatePadding(top = statusBarInsets.top)
            insets
        }

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Всегда показываем «Заявки» всем пользователям
        navigationView.menu.findItem(R.id.adminFragment)?.isVisible = true

        // Header
        val prefs = getSharedPreferences("IN", MODE_PRIVATE)
        val isAdmin = prefs.getString("phone", "") == "123456789"
        val uid   = prefs.getString("ID", null)
        val headerView = navigationView.getHeaderView(0)
        val nameTextView    = headerView.findViewById<TextView>(R.id.nav_header_name)
        val profileImageView= headerView.findViewById<ImageView>(R.id.navProfileImageView)

        uid?.let {
            FirebaseFirestore.getInstance()
                .collection("users").document(it)
                .get()
                .addOnSuccessListener { doc ->
                    nameTextView.text = doc.getString("name") ?: "Пользователь"
                    doc.getString("profileImageUrl")?.let { url ->
                        Glide.with(this).load(url).into(profileImageView)
                    }
                }
        }

        profileImageView.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK).apply { type = "image/*" }
            startActivityForResult(intent, PICK_IMAGE_REQUEST)
        }

        if (savedInstanceState == null) {
            openFragment(HomeFragment())
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home          -> openFragment(HomeFragment())
                R.id.profile       -> openFragment(ProfileFragment())
                R.id.nav_favorites -> openFragment(FavoritesFragment())
                R.id.my_pets       -> openFragment(MyPetsFragment())
                R.id.nav_add_pet   -> openFragment(AddPetFragment())
                R.id.nav_chat -> {
                    val uid = prefs.getString("ID", null)
                    if (uid.isNullOrEmpty()) {
                        Toast.makeText(this, "Пожалуйста, войдите в систему", Toast.LENGTH_SHORT).show()
                    } else if (isAdmin) {
                        startActivity(Intent(this, AdminChatListActivity::class.java))
                    } else {
                        val intent = Intent(this, UserChatActivity::class.java)
                        intent.putExtra("userId", uid)
                        startActivity(intent)
                    }
                }
                R.id.adminFragment -> openFragment(AdminRequestsFragment())
                else -> return@setNavigationItemSelectedListener false
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home          -> openFragment(HomeFragment())
                R.id.profile       -> openFragment(ProfileFragment())
                R.id.nav_add_pet   -> openFragment(AddPetFragment())
                R.id.nav_favorites -> openFragment(FavoritesFragment())
                else               -> return@setOnItemSelectedListener false
            }
            true
        }
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    private fun openFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.data != null) {
            selectedImageUri = data.data

            selectedImageUri?.let { uri ->
                val inputStream = contentResolver.openInputStream(uri)
                val tempFile = File.createTempFile("upload", ".jpg", cacheDir)
                tempFile.outputStream().use { fileOut ->
                    inputStream?.copyTo(fileOut)
                }
                uploadImageToCloudinary(tempFile)
            }
        }
    }

    private fun uploadImageToCloudinary(file: File) {
        val prefs = getSharedPreferences("IN", MODE_PRIVATE)
        val uid = prefs.getString("ID", null) ?: return

        val config = hashMapOf(
            "cloud_name" to "dfwednqqy",
            "api_key" to "478855117939718",
            "api_secret" to "Faw_qHD1RmBmDPMO_4IkriMvPCk"
        )
        val cloudinary = Cloudinary(config)

        Thread {
            try {
                val result = cloudinary.uploader().upload(file, ObjectUtils.emptyMap())
                val imageUrl = result["secure_url"] as String

                FirebaseFirestore.getInstance().collection("users").document(uid)
                    .update("profileImageUrl", imageUrl)
                    .addOnSuccessListener {
                        runOnUiThread {
                            val headerView = navigationView.getHeaderView(0)
                            val profileImageView = headerView.findViewById<ImageView>(R.id.navProfileImageView)
                            Glide.with(this).load(imageUrl).into(profileImageView)
                            Toast.makeText(this, "Фото обновлено", Toast.LENGTH_SHORT).show()
                        }
                    }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this, "Ошибка загрузки фото", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun getRealPathFromURI(context: Context, uri: Uri): String? {
        val projection = arrayOf(MediaStore.Images.Media.DATA)
        context.contentResolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                return cursor.getString(columnIndex)
            }
        }
        return null
    }
}
