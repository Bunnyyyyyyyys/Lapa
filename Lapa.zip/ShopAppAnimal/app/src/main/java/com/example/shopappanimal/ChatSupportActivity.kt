package com.example.shopappanimal

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import android.util.Log

class ChatSupportActivity : AppCompatActivity() {
    private val db by lazy { FirebaseFirestore.getInstance() }
    private lateinit var auth: FirebaseAuth
    private lateinit var userId: String
    private lateinit var adapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()
    private val encryptionHelper = EncryptionHelper("G8BnK9Qfuntk9vl6")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_support)

        auth = FirebaseAuth.getInstance()
        val current = auth.currentUser
        if (current == null) {
            Toast.makeText(this, "Пользователь не авторизован", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        userId = current.uid

        // Получаем данные пользователя
        db.collection("users").document(userId).get()
            .addOnSuccessListener { userDoc ->
                val encryptedPhone = userDoc.getString("phone") ?: ""
                val decryptedPhone = try {
                    encryptionHelper.decrypt(encryptedPhone)
                } catch (e: Exception) {
                    ""
                }

                val name = userDoc.getString("name") ?: ""

                // Сохраняем имя и зашифрованный номер в supportChats
                val chatRef = db.collection("supportChats").document(userId)
                val userInfo = hashMapOf(
                    "userPhone" to encryptionHelper.encrypt(decryptedPhone),
                    "userName" to name
                )
                chatRef.set(userInfo, SetOptions.merge())

                // Заголовок с расшифрованным телефоном и именем
                supportActionBar?.title = "Чат с $name (${if (decryptedPhone.isNotBlank()) decryptedPhone else "без телефона"})"
            }
            .addOnFailureListener {
                Log.e("ChatSupport", "Ошибка загрузки данных пользователя", it)
            }

        // RecyclerView
        val rv = findViewById<RecyclerView>(R.id.messagesRecycler)
        adapter = ChatAdapter(messages, userId)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        // Слушаем сообщения
        db.collection("supportChats")
            .document(userId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    Log.w("ChatSupport", "Ошибка получения сообщений", e)
                    return@addSnapshotListener
                }
                messages.clear()
                snap?.toObjects(ChatMessage::class.java)?.let { messages.addAll(it) }
                adapter.notifyDataSetChanged()
                rv.scrollToPosition(messages.size - 1)
            }

        // Отправка сообщения
        findViewById<Button>(R.id.sendButton).setOnClickListener {
            val input = findViewById<EditText>(R.id.messageInput)
            val text = input.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val encryptedPhone = encryptionHelper.encrypt(current.phoneNumber ?: "")

            val msg = ChatMessage(
                senderId = userId,
                message = text,
                timestamp = Timestamp.now(),
                senderPhone = encryptedPhone
            )

            val chatRef = db.collection("supportChats").document(userId)
            chatRef.set(mapOf("userPhone" to encryptedPhone), SetOptions.merge())
            chatRef.collection("messages").add(msg)
            input.text.clear()
        }
    }
}
